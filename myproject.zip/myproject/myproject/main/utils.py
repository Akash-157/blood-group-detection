import math
import numpy as np
from io import BytesIO
from pathlib import Path
from django.conf import settings
from PIL import Image

from tensorflow.keras.models import load_model

# Use MobileNetV2 preprocessing if available; otherwise no-op
try:
    from tensorflow.keras.applications.mobilenet_v2 import preprocess_input as mobilenet_preprocess
except Exception:  # pragma: no cover
    def mobilenet_preprocess(x):
        return x

# ----- Label map (edit if your class order differs) -----
BLOOD_LABELS = ['A-', 'A+', 'AB-', 'AB+', 'B-', 'B+', 'O-', 'O+']

# ----- Model cache -----
_model_cache = None


# ===== Path resolution =====
def _find_model_path() -> Path:
    """
    Resolve the model path robustly:
      1) settings.BLOOD_MODEL_PATH (absolute or relative to BASE_DIR)
      2) <BASE_DIR>/models/mobilenetv2_model.hdf5
      3) <BASE_DIR>/models/mobilenetv2_model.h5
      4) <BASE_DIR>/models/model.h5
    """
    # 1) explicit setting
    cand = getattr(settings, 'BLOOD_MODEL_PATH', None)
    if cand:
        p = Path(cand)
        if not p.is_absolute():
            p = Path(settings.BASE_DIR) / p
        if p.exists():
            return p

    # 2-4) common fallbacks
    base = Path(settings.BASE_DIR) / 'models'
    candidates = [
        base / 'mobilenetv2_model.hdf5',
        base / 'mobilenetv2_model.h5',
        base / 'model.h5',
    ]
    for c in candidates:
        if c.exists():
            return c

    raise FileNotFoundError(
        "Model file not found. Place your model at one of: "
        + ", ".join(str(c) for c in candidates)
        + " or set settings.BLOOD_MODEL_PATH to the correct path."
    )


def get_model():
    """Load once and cache."""
    global _model_cache
    if _model_cache is None:
        model_path = _find_model_path()
        _model_cache = load_model(model_path)
    return _model_cache


# ===== Input spec helpers =====
def _model_input_spec():
    """
    Returns (height, width, channels) from the model input shape.
    Falls back to (224, 224, 3) if unknown.
    """
    m = get_model()
    ishape = m.input_shape  # e.g., (None, 224, 224, 3) or list of such
    if isinstance(ishape, (list, tuple)) and ishape and isinstance(ishape[0], (list, tuple)):
        ishape = ishape[0]
    # ishape now like (None, H, W, C)
    h = ishape[1] if len(ishape) > 1 else None
    w = ishape[2] if len(ishape) > 2 else None
    c = ishape[3] if len(ishape) > 3 else None
    h = int(h) if isinstance(h, int) else 224
    w = int(w) if isinstance(w, int) else 224
    c = int(c) if (isinstance(c, int) and c > 0) else 3
    return h, w, c


# ===== Image I/O + preprocessing =====
def _pil_from_upload(upload) -> Image.Image:
    """
    Safely open Django UploadedFile (InMemory or Temporary) as PIL.Image in RGB.
    """
    data = upload.read()
    try:
        upload.seek(0)
    except Exception:
        pass
    img = Image.open(BytesIO(data))
    # Force RGB to start with a known baseline (3 channels)
    img = img.convert('RGB')
    return img


def prepare_image(uploaded_file):
    """
    Convert uploaded image to a NumPy batch tensor shaped exactly as the model expects:
    (1, H, W, C_expected), with C_expected read from model.input_shape.
    - Resizes to (H, W)
    - Ensures channels == expected (truncate extras, or tile/pad if fewer)
    - Applies MobileNetV2 preprocess (no-op fallback if unavailable)
    """
    H, W, C_expected = _model_input_spec()

    pil_img = _pil_from_upload(uploaded_file)
    pil_img = pil_img.resize((W, H))  # PIL uses (width, height)
    arr = np.array(pil_img)

    # arr now (H, W, 3) because we converted to RGB above
    # If your model expects a different number of channels (rare, e.g., 9),
    # we adapt by truncating or tiling.
    if arr.ndim == 2:
        # grayscale safeguard (shouldn't happen since we convert RGB)
        arr = np.stack([arr] * 3, axis=-1)

    c = arr.shape[-1]
    if c > C_expected:
        arr = arr[..., :C_expected]
    elif c < C_expected:
        reps = int(math.ceil(C_expected / c))
        arr = np.tile(arr, (1, 1, reps))[..., :C_expected]

    x = arr.astype(np.float32)
    x = np.expand_dims(x, axis=0)  # (1, H, W, C_expected)
    x = mobilenet_preprocess(x)

    # Final safety check
    if x.shape[-1] != C_expected:
        raise RuntimeError(
            f"Preprocessed tensor has {x.shape[-1]} channels; expected {C_expected}"
        )
    if x.shape[1] != H or x.shape[2] != W:
        raise RuntimeError(
            f"Preprocessed tensor spatial size is {(x.shape[1], x.shape[2])}; expected {(H, W)}"
        )

    return x


def predict_blood_group(uploaded_file) -> dict:
    """
    Run inference and return {'label': str, 'confidence': float%}
    """
    model = get_model()
    x = prepare_image(uploaded_file)

    preds = model.predict(x)
    probs = preds[0] if preds.ndim == 2 else preds
    probs = probs.astype(float)

    idx = int(np.argmax(probs))
    label = BLOOD_LABELS[idx] if idx < len(BLOOD_LABELS) else f"Class {idx}"

    # get confidence; normalize via softmax if not in [0,1]
    conf = float(probs[idx]) if idx < len(probs) else float(np.max(probs))
    if conf > 1.0 or conf < 0.0:
        exps = np.exp(probs - np.max(probs))
        softmax = exps / np.sum(exps)
        conf = float(softmax[idx])

    return {'label': label, 'confidence': round(conf * 100, 2)}
