from django import forms


class FingerprintForm(forms.Form):
    image = forms.ImageField(required=True)