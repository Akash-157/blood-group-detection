from django.shortcuts import render
from django.http import JsonResponse
from .forms import FingerprintForm
from .utils import predict_blood_group

SITE_TITLE = "Blood Group Detection Using Fingerprint"
SITE_BRAND = "BioDetect"


def _nav():
    return [
        {'name': 'Home', 'url': 'main:home'},
        {'name': 'About', 'url': 'main:about'},
        {'name': 'Demo', 'url': 'main:demo'},
        {'name': 'Contact', 'url': 'main:contact'},
    ]


def home(request):
    return render(request, 'main/home.html', {
        'title': SITE_TITLE,
        'brand': SITE_BRAND,
        'nav': _nav(),
        'active': 'Home',
    })


def about(request):
    return render(request, 'main/about.html', {
        'title': SITE_TITLE,
        'brand': SITE_BRAND,
        'nav': _nav(),
        'active': 'About',
    })


def demo(request):
    form = FingerprintForm()
    return render(request, 'main/demo.html', {
        'title': SITE_TITLE,
        'brand': SITE_BRAND,
        'nav': _nav(),
        'active': 'Demo',
        'form': form,
    })


def contact(request):
    return render(request, 'main/contact.html', {
        'title': SITE_TITLE,
        'brand': SITE_BRAND,
        'nav': _nav(),
        'active': 'Contact',
    })


def predict(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST only'}, status=405)

    form = FingerprintForm(request.POST, request.FILES)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'error': 'Invalid or missing file.'}, status=400)

    try:
        result = predict_blood_group(request.FILES['image'])
        return JsonResponse({'ok': True, **result})
    except FileNotFoundError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=500)
    except Exception as e:
        # Surface precise preprocessing/model errors for quick debugging
        return JsonResponse({'ok': False, 'error': f'Prediction failed: {e}'}, status=500)
