from django.urls import path
from . import views


app_name = 'main'


urlpatterns = [
path('', views.home, name='home'),
path('about/', views.about, name='about'),
path('demo/', views.demo, name='demo'),
path('contact/', views.contact, name='contact'),
path('predict/', views.predict, name='predict'), # POST endpoint for prediction
]